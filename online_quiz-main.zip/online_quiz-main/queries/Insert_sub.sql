-- SQLite
INSERT INTO classroom_subject (id, name, color)
VALUES 
(1,"Arts","#343a40"),
(2,"Computing","#007bff"),
(3,"Math","#28a745"),
(4,"Biology","#17a2b8"),
(5,"History","#ffc107")
;